#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MRCTP-Multi: 面向测试资源分配的软件模块风险聚类与测试优先级排序实验

数据集：NASA/PROMISE 本地数据集 jm1、kc1、kc2、pc1
要求：不自动下载数据。请将数据文件放在 data/ 目录下，例如：
    data/jm1.arff 或 data/jm1.csv
    data/kc1.arff 或 data/kc1.csv
    data/kc2.arff 或 data/kc2.csv
    data/pc1.arff 或 data/pc1.csv

运行示例：
    pip install -r requirements.txt
    python run_mrctp_multi_dataset.py --data_dir data --result_dir results

输出：
    results/ALL_summary_metrics.csv
    results/ALL_cluster_metrics.csv
    results/ALL_k_selection.csv
    results/ALL_best_by_apfd.csv
    results/<dataset>/summary_metrics.csv
    results/<dataset>/cluster_metrics.csv
    results/<dataset>/k_selection.csv
    results/<dataset>/cluster_table.csv
    results/<dataset>/module_priority_and_clusters.csv
"""

from __future__ import annotations

import argparse
import os
# Limit BLAS/OpenMP threads to avoid small/medium datasets running slowly on some machines.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
import csv
import math
import re
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.impute import SimpleImputer
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.preprocessing import MinMaxScaler, StandardScaler

try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None

DEFAULT_DATASETS = ["jm1", "kc1", "kc2", "pc1"]
SUPPORTED_EXTS = [".arff", ".csv", ".txt"]

# 与测试资源分配和缺陷风险较相关的静态度量。若某些列不存在，程序会自动跳过。
RISK_FEATURES = [
    "loc", "v(g)", "ev(g)", "iv(g)", "n", "v", "d", "e", "t",
    "lOCode", "locode", "loc_code", "lOComment", "locomment", "lOBlank", "loblank",
    "uniq_Op", "uniq_op", "uniq_Opnd", "uniq_opnd", "total_Op", "total_op",
    "total_Opnd", "total_opnd", "branchCount", "branchcount",
]

BASELINES = ["random", "loc", "cyclomatic", "kmeans_risk", "mrctp"]


def normalize_col_name(name: str) -> str:
    """Normalize feature/label names for robust matching."""
    return str(name).strip().strip("'\"").replace(" ", "_")


def find_dataset_file(data_dir: Path, dataset: str) -> Path:
    """Find a local dataset file by exact stem name, without downloading anything."""
    dataset_lower = dataset.lower()
    if not data_dir.exists():
        raise FileNotFoundError(f"数据目录不存在：{data_dir}")

    # First: exact common file names at data_dir root.
    for ext in SUPPORTED_EXTS:
        for name in [dataset_lower, dataset_lower.upper(), dataset_lower.capitalize()]:
            p = data_dir / f"{name}{ext}"
            if p.exists() and p.is_file():
                return p

    # Second: recursive stem match, useful when files are placed in subfolders.
    candidates: List[Path] = []
    for p in data_dir.rglob("*"):
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS and p.stem.lower() == dataset_lower:
            candidates.append(p)
    if candidates:
        # Prefer ARFF, then CSV, then shorter path.
        candidates = sorted(candidates, key=lambda x: (SUPPORTED_EXTS.index(x.suffix.lower()), len(str(x))))
        return candidates[0]

    available = sorted(
        str(p.relative_to(data_dir)) for p in data_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS
    )
    preview = ", ".join(available[:20]) if available else "未发现 .arff/.csv/.txt 数据文件"
    raise FileNotFoundError(
        f"没有找到数据集 {dataset}。请放置为 data/{dataset}.arff 或 data/{dataset}.csv。\n"
        f"当前 data 目录可用文件：{preview}"
    )


def _parse_attribute(line: str) -> Optional[str]:
    """Parse an ARFF @attribute line and return the attribute name."""
    # Handles:
    # @attribute loc numeric
    # @attribute 'lOCodeAndComment' numeric
    m = re.match(r"@attribute\s+(['\"]?)(.+?)\1\s+(.+)$", line.strip(), flags=re.I)
    if not m:
        return None
    return normalize_col_name(m.group(2))


def load_arff(path: Path) -> pd.DataFrame:
    """A lightweight ARFF parser for NASA/PROMISE dense ARFF files."""
    attrs: List[str] = []
    rows: List[List[str]] = []
    in_data = False

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("%"):
                continue
            low = line.lower()
            if low.startswith("@attribute"):
                name = _parse_attribute(line)
                if name is not None:
                    attrs.append(name)
                continue
            if low.startswith("@data"):
                in_data = True
                continue
            if in_data:
                # NASA/PROMISE files are dense rows. Skip sparse ARFF rows if present.
                if line.startswith("{") and line.endswith("}"):
                    raise ValueError(
                        f"检测到稀疏 ARFF 行，当前轻量解析器不支持：{path}。"
                        "请将数据转换为 CSV 后再运行。"
                    )
                parts = next(csv.reader([line]))
                if len(parts) == len(attrs):
                    rows.append([p.strip() for p in parts])

    if not attrs or not rows:
        raise ValueError(f"ARFF parsing failed: no attributes or rows found in {path}")

    return pd.DataFrame(rows, columns=attrs)


def load_table(path: Path) -> pd.DataFrame:
    """Load ARFF/CSV/TXT dataset."""
    suffix = path.suffix.lower()
    if suffix == ".arff":
        df = load_arff(path)
    elif suffix in {".csv", ".txt"}:
        # sep=None lets pandas infer comma/semicolon/tab separators.
        df = pd.read_csv(path, sep=None, engine="python")
        df.columns = [normalize_col_name(c) for c in df.columns]
    else:
        raise ValueError(f"Unsupported data file type: {path.suffix}")

    # Drop fully empty columns and normalize column names.
    df.columns = [normalize_col_name(c) for c in df.columns]
    df = df.dropna(axis=1, how="all")
    return df


def find_label_column(df: pd.DataFrame) -> str:
    """Find defect label column in common NASA/PROMISE naming styles."""
    exact_names = {
        "defects", "defect", "bug", "bugs", "label", "class", "fault", "faults",
        "problems", "problem", "is_defective", "defective"
    }
    lower_map = {c.lower(): c for c in df.columns}
    for name in exact_names:
        if name in lower_map:
            return lower_map[name]

    # Many PROMISE files place class label as the last column.
    last_col = df.columns[-1]
    last_values = set(df[last_col].astype(str).str.strip().str.lower().dropna().unique()[:20])
    label_tokens = {"true", "false", "yes", "no", "y", "n", "0", "1", "clean", "defective"}
    if last_values and last_values.issubset(label_tokens):
        return last_col

    raise ValueError(f"Cannot find defect label column. Columns={list(df.columns)}")


def label_to_binary(series: pd.Series) -> pd.Series:
    """Convert common defect labels to 0/1."""
    s = series.astype(str).str.strip().str.lower()
    mapping = {
        "true": 1, "yes": 1, "1": 1, "y": 1, "defective": 1, "buggy": 1,
        "faulty": 1, "problem": 1, "problems": 1,
        "false": 0, "no": 0, "0": 0, "n": 0, "clean": 0, "non-defective": 0,
        "nondefective": 0, "not_defective": 0,
    }
    y = s.map(mapping)
    if y.isna().any():
        # Numeric fallback: values > 0 are defective.
        numeric = pd.to_numeric(series, errors="coerce")
        if numeric.notna().sum() == len(series):
            y = (numeric > 0).astype(int)
        else:
            # Last fallback: non-false-like values are considered defective.
            y = s.apply(lambda v: 0 if v in {"false", "no", "0", "n", "clean"} else 1)
    return y.astype(int)


def load_dataset(path: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, str]:
    """Load dataset and return raw dataframe, numeric features, binary labels, label column."""
    df = load_table(path)
    label_col = find_label_column(df)
    y = label_to_binary(df[label_col])

    X_raw = df.drop(columns=[label_col]).copy()
    # Convert '?' and nonnumeric values to NaN. Object identifier columns are dropped later if all NaN.
    for col in X_raw.columns:
        X_raw[col] = pd.to_numeric(X_raw[col].replace("?", np.nan), errors="coerce")
    X_raw = X_raw.dropna(axis=1, how="all")
    if X_raw.shape[1] == 0:
        raise ValueError(f"No numeric feature columns found in {path}")
    return df, X_raw, y, label_col


def preprocess_features(X_raw: pd.DataFrame) -> Tuple[np.ndarray, pd.DataFrame, List[str]]:
    """Impute, log-transform skewed nonnegative metrics, and standardize."""
    X = X_raw.replace([np.inf, -np.inf], np.nan).copy()
    feature_names = list(X.columns)

    imputer = SimpleImputer(strategy="median")
    X_imp = pd.DataFrame(imputer.fit_transform(X), columns=feature_names)

    # Static metrics are usually long-tailed; log1p improves clustering stability.
    X_log = X_imp.copy()
    for col in feature_names:
        values = X_imp[col].values.astype(float)
        if np.nanmin(values) >= 0 and pd.Series(values).skew() > 1.0:
            X_log[col] = np.log1p(values)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_log.values)
    return X_scaled, X_imp, feature_names


def compute_base_risk(X_num: pd.DataFrame) -> np.ndarray:
    """Compute an unsupervised module complexity/risk score in [0, 1]."""
    lower_to_col = {c.lower(): c for c in X_num.columns}
    selected: List[str] = []
    for c in RISK_FEATURES:
        if c.lower() in lower_to_col and lower_to_col[c.lower()] not in selected:
            selected.append(lower_to_col[c.lower()])
    if not selected:
        selected = list(X_num.columns)

    values_df = X_num[selected].copy()
    values_df = values_df.replace([np.inf, -np.inf], np.nan)
    values_df = values_df.fillna(values_df.median(numeric_only=True))
    values = np.log1p(np.maximum(values_df.values.astype(float), 0.0))

    if values.shape[1] == 1:
        scaled = MinMaxScaler().fit_transform(values)
    else:
        scaled = MinMaxScaler().fit_transform(values)

    weights = np.ones(len(selected), dtype=float)
    high_weight_names = {"loc", "locode", "v(g)", "ev(g)", "iv(g)", "branchcount", "e", "t"}
    for i, col in enumerate(selected):
        if col.lower() in high_weight_names:
            weights[i] = 1.5
    weights = weights / weights.sum()
    risk = scaled @ weights
    return MinMaxScaler().fit_transform(risk.reshape(-1, 1)).ravel()


def parse_k_values(text: str, n_samples: int) -> List[int]:
    values = sorted({int(x) for x in text.split(",") if x.strip()})
    return [k for k in values if 2 <= k < n_samples]


def select_k_and_cluster(
    X_scaled: np.ndarray,
    k_values: Iterable[int],
    random_state: int,
) -> Tuple[int, np.ndarray, KMeans, pd.DataFrame]:
    """Select k by silhouette score and return the final KMeans model."""
    n = X_scaled.shape[0]
    rng = np.random.default_rng(random_state)
    sample_size = min(2500, n)
    sample_idx = rng.choice(n, size=sample_size, replace=False) if n > sample_size else np.arange(n)

    rows = []
    best = None
    for k in k_values:
        if k < 2 or k >= n:
            continue
        model = KMeans(
            n_clusters=k,
            random_state=random_state,
            n_init=10,
            max_iter=200,
            algorithm="lloyd",
        )
        labels = model.fit_predict(X_scaled)
        try:
            sil = silhouette_score(X_scaled[sample_idx], labels[sample_idx], metric="euclidean")
        except Exception:
            sil = np.nan
        rows.append({"k": k, "silhouette": sil, "inertia": float(model.inertia_)})
        key = -np.inf if np.isnan(sil) else sil
        if best is None or key > best[0]:
            best = (key, k, labels, model)

    if best is None:
        raise RuntimeError("No valid k in candidate list.")
    _, best_k, best_labels, best_model = best
    return best_k, best_labels, best_model, pd.DataFrame(rows)


def cluster_risk_scores(
    X_scaled: np.ndarray,
    labels: np.ndarray,
    centers: np.ndarray,
    base_risk: np.ndarray,
) -> Tuple[np.ndarray, pd.DataFrame, np.ndarray]:
    """Compute cluster-level risk and sample boundary distance."""
    k = int(labels.max()) + 1
    dists = np.linalg.norm(X_scaled - centers[labels], axis=1)
    boundary_distance = MinMaxScaler().fit_transform(dists.reshape(-1, 1)).ravel()

    rows = []
    raw_scores = np.zeros(k, dtype=float)
    for c in range(k):
        idx = labels == c
        size = int(idx.sum())
        mean_risk = float(base_risk[idx].mean()) if size else 0.0
        mean_dist = float(boundary_distance[idx].mean()) if size else 0.0
        size_factor = math.log1p(size) / math.log1p(len(labels)) if len(labels) else 0.0
        raw = 0.65 * mean_risk + 0.25 * mean_dist + 0.10 * size_factor
        raw_scores[c] = raw
        rows.append({
            "cluster": c,
            "size": size,
            "mean_base_risk": mean_risk,
            "mean_boundary_distance": mean_dist,
            "size_factor": size_factor,
            "raw_cluster_risk": raw,
        })

    cluster_scores = MinMaxScaler().fit_transform(raw_scores.reshape(-1, 1)).ravel()
    out = pd.DataFrame(rows)
    out["cluster_risk"] = out["cluster"].map({i: cluster_scores[i] for i in range(k)})
    return cluster_scores, out, boundary_distance


def purity_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    total = len(y_true)
    if total == 0:
        return float("nan")
    score = 0
    classes = np.unique(y_true.astype(int))
    min_class = int(classes.min()) if len(classes) else 0
    shifted = y_true.astype(int) - min_class
    n_class = int(shifted.max()) + 1 if len(shifted) else 1
    for c in np.unique(y_pred):
        idx = y_pred == c
        counts = np.bincount(shifted[idx], minlength=n_class)
        score += counts.max()
    return float(score / total)


def apfd(y_true: np.ndarray, ranking: np.ndarray) -> float:
    """Average Percentage of Faults Detected for module/test order."""
    y_ordered = y_true[ranking]
    n = len(y_ordered)
    m = int(y_ordered.sum())
    if m == 0 or n == 0:
        return float("nan")
    fault_positions = np.where(y_ordered == 1)[0] + 1  # 1-based
    return float(1.0 - fault_positions.sum() / (n * m) + 1.0 / (2 * n))


def top_recall(y_true: np.ndarray, ranking: np.ndarray, frac: float) -> float:
    n_top = max(1, int(math.ceil(len(y_true) * frac)))
    total_faults = int(y_true.sum())
    if total_faults == 0:
        return float("nan")
    return float(y_true[ranking[:n_top]].sum() / total_faults)


def top_precision(y_true: np.ndarray, ranking: np.ndarray, frac: float) -> float:
    n_top = max(1, int(math.ceil(len(y_true) * frac)))
    return float(y_true[ranking[:n_top]].mean())


def make_rankings(
    X_num: pd.DataFrame,
    y: np.ndarray,
    labels: np.ndarray,
    base_risk: np.ndarray,
    cluster_scores: np.ndarray,
    boundary_distance: np.ndarray,
    random_state: int,
) -> Tuple[Dict[str, np.ndarray], np.ndarray]:
    rng = np.random.default_rng(random_state)
    n = len(y)

    lower_to_col = {c.lower(): c for c in X_num.columns}
    loc_col = lower_to_col.get("loc") or lower_to_col.get("locode")
    cyclo_col = lower_to_col.get("v(g)") or lower_to_col.get("branchcount")

    loc = X_num[loc_col].to_numpy(float) if loc_col else base_risk
    cyclomatic = X_num[cyclo_col].to_numpy(float) if cyclo_col else base_risk

    kmeans_cluster_score = cluster_scores[labels]
    mrctp_score = 0.50 * kmeans_cluster_score + 0.35 * base_risk + 0.15 * boundary_distance

    rankings = {
        "random": rng.permutation(n),
        "loc": np.argsort(-np.nan_to_num(loc, nan=np.nanmedian(loc))),
        "cyclomatic": np.argsort(-np.nan_to_num(cyclomatic, nan=np.nanmedian(cyclomatic))),
        "kmeans_risk": np.lexsort((-base_risk, -kmeans_cluster_score)),
        "mrctp": np.argsort(-mrctp_score),
    }
    return rankings, mrctp_score


def cumulative_curve(y_true: np.ndarray, ranking: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    y_ord = y_true[ranking]
    total = max(1, int(y_ord.sum()))
    x = np.arange(1, len(y_ord) + 1) / len(y_ord)
    yy = np.cumsum(y_ord) / total
    return x, yy


def save_plots(result_dir: Path, dataset: str, y: np.ndarray, rankings: Dict[str, np.ndarray], cluster_table: pd.DataFrame) -> None:
    if plt is None:
        print("[Plot] matplotlib is unavailable; skip plots.")
        return

    result_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    plt.figure(figsize=(7, 4.5))
    for name, ranking in rankings.items():
        x, yy = cumulative_curve(y, ranking)
        plt.plot(x, yy, label=name)
    plt.xlabel("Test ratio")
    plt.ylabel("Detected defect ratio")
    plt.title(f"{dataset.upper()} fault detection curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(result_dir / "fault_detection_curve.png", dpi=200)
    plt.close()

    plt.figure(figsize=(7, 4.5))
    ordered = cluster_table.sort_values("cluster")
    plt.bar(ordered["cluster"].astype(str), ordered["cluster_risk"])
    plt.xlabel("Cluster ID")
    plt.ylabel("Cluster risk score")
    plt.title(f"{dataset.upper()} cluster risk scores")
    plt.tight_layout()
    plt.savefig(result_dir / "cluster_risk_scores.png", dpi=200)
    plt.close()


def run_one_dataset(dataset: str, dataset_path: Path, args: argparse.Namespace) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Run experiment on one local dataset and save per-dataset outputs."""
    start = time.time()
    out_dir = Path(args.result_dir) / dataset.lower()
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n==============================")
    print(f"Dataset: {dataset.upper()}")
    print(f"File   : {dataset_path}")
    print(f"Output : {out_dir}")

    df, X_raw, y_series, label_col = load_dataset(dataset_path)
    y = y_series.to_numpy(dtype=int)
    X_scaled, X_num, feature_names = preprocess_features(X_raw)
    base_risk = compute_base_risk(X_num)

    k_values = parse_k_values(args.k_values, len(y))
    if not k_values:
        raise ValueError(f"No valid k_values for dataset {dataset}. n={len(y)}, k_values={args.k_values}")

    best_k, labels, model, k_table = select_k_and_cluster(X_scaled, k_values, args.seed)
    cluster_scores, cluster_table, boundary_distance = cluster_risk_scores(
        X_scaled, labels, model.cluster_centers_, base_risk
    )
    rankings, mrctp_score = make_rankings(X_num, y, labels, base_risk, cluster_scores, boundary_distance, args.seed)

    runtime = time.time() - start
    defect_rate = float(y.mean())

    summary_rows = []
    for name in BASELINES:
        ranking = rankings[name]
        summary_rows.append({
            "dataset": dataset.upper(),
            "method": name,
            "best_k": best_k if name in {"kmeans_risk", "mrctp"} else "-",
            "instances": len(y),
            "features": len(feature_names),
            "defects": int(y.sum()),
            "defect_rate": defect_rate,
            "APFD": apfd(y, ranking),
            "Precision@10%": top_precision(y, ranking, 0.10),
            "Recall@10%": top_recall(y, ranking, 0.10),
            "Recall@20%": top_recall(y, ranking, 0.20),
            "Recall@30%": top_recall(y, ranking, 0.30),
            "runtime_seconds": runtime,
        })

    cluster_metrics = {
        "dataset": dataset.upper(),
        "file": str(dataset_path),
        "label_column": label_col,
        "instances": len(y),
        "features": len(feature_names),
        "defects": int(y.sum()),
        "defect_rate": defect_rate,
        "NMI_defect_vs_cluster": normalized_mutual_info_score(y, labels),
        "ARI_defect_vs_cluster": adjusted_rand_score(y, labels),
        "Purity_defect_vs_cluster": purity_score(y, labels),
        "selected_k": best_k,
        "runtime_seconds": runtime,
    }

    summary = pd.DataFrame(summary_rows)
    cluster_metrics_df = pd.DataFrame([cluster_metrics])
    k_table.insert(0, "dataset", dataset.upper())
    cluster_table.insert(0, "dataset", dataset.upper())

    summary.to_csv(out_dir / "summary_metrics.csv", index=False, encoding="utf-8-sig")
    cluster_metrics_df.to_csv(out_dir / "cluster_metrics.csv", index=False, encoding="utf-8-sig")
    k_table.to_csv(out_dir / "k_selection.csv", index=False, encoding="utf-8-sig")
    cluster_table.to_csv(out_dir / "cluster_table.csv", index=False, encoding="utf-8-sig")

    assignment = X_raw.copy()
    assignment.insert(0, "dataset", dataset.upper())
    assignment.insert(1, "module_id", np.arange(len(y)))
    assignment["defect"] = y
    assignment["cluster"] = labels
    assignment["base_risk"] = base_risk
    assignment["boundary_distance"] = boundary_distance
    assignment["cluster_risk"] = cluster_scores[labels]
    assignment["mrctp_score"] = mrctp_score
    # rank 1 means highest priority.
    rank = np.empty_like(np.argsort(-mrctp_score))
    rank[np.argsort(-mrctp_score)] = np.arange(1, len(mrctp_score) + 1)
    assignment["mrctp_rank"] = rank
    assignment.sort_values("mrctp_rank").to_csv(
        out_dir / "module_priority_and_clusters.csv", index=False, encoding="utf-8-sig"
    )

    if args.save_plots:
        save_plots(out_dir, dataset, y, rankings, cluster_table)

    print(summary.to_string(index=False))
    print("Cluster metrics:")
    for k, v in cluster_metrics.items():
        print(f"  {k}: {v}")

    return summary, cluster_metrics_df, k_table


def parse_dataset_list(text: str) -> List[str]:
    if text.strip().lower() == "all":
        return DEFAULT_DATASETS
    return [x.strip().lower() for x in text.split(",") if x.strip()]


def run_experiment(args: argparse.Namespace) -> None:
    result_dir = Path(args.result_dir)
    data_dir = Path(args.data_dir)
    result_dir.mkdir(parents=True, exist_ok=True)

    datasets = parse_dataset_list(args.datasets)
    print("========== MRCTP-Multi Experiment ==========")
    print(f"Data directory  : {data_dir.resolve()}")
    print(f"Result directory: {result_dir.resolve()}")
    print(f"Datasets        : {', '.join(datasets).upper()}")
    print("Mode            : local files only, no automatic download")

    all_summary: List[pd.DataFrame] = []
    all_cluster_metrics: List[pd.DataFrame] = []
    all_k_selection: List[pd.DataFrame] = []
    failures: List[Dict[str, str]] = []

    for dataset in datasets:
        try:
            dataset_path = find_dataset_file(data_dir, dataset)
            summary, cluster_metrics, k_table = run_one_dataset(dataset, dataset_path, args)
            all_summary.append(summary)
            all_cluster_metrics.append(cluster_metrics)
            all_k_selection.append(k_table)
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            print(f"[Failed] {dataset.upper()} -> {msg}")
            failures.append({"dataset": dataset.upper(), "error": msg})
            if not args.skip_failed:
                raise

    if all_summary:
        summary_all = pd.concat(all_summary, ignore_index=True)
        cluster_all = pd.concat(all_cluster_metrics, ignore_index=True)
        k_all = pd.concat(all_k_selection, ignore_index=True)

        summary_all.to_csv(result_dir / "ALL_summary_metrics.csv", index=False, encoding="utf-8-sig")
        cluster_all.to_csv(result_dir / "ALL_cluster_metrics.csv", index=False, encoding="utf-8-sig")
        k_all.to_csv(result_dir / "ALL_k_selection.csv", index=False, encoding="utf-8-sig")

        best_by_apfd = summary_all.sort_values(["dataset", "APFD"], ascending=[True, False]).groupby("dataset").head(1)
        best_by_apfd.to_csv(result_dir / "ALL_best_by_apfd.csv", index=False, encoding="utf-8-sig")

        print("\n========== All datasets summary ==========")
        print(summary_all.to_string(index=False))
        print(f"\n[Output] Combined results saved to: {result_dir.resolve()}")

    if failures:
        pd.DataFrame(failures).to_csv(result_dir / "FAILED_datasets.csv", index=False, encoding="utf-8-sig")
        print("\n========== Failed datasets ==========")
        for item in failures:
            print(f"{item['dataset']}: {item['error']}")


def parse_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="MRCTP software testing + clustering experiment on local JM1/KC1/KC2/PC1 datasets"
    )
    parser.add_argument("--data_dir", default="data", help="本地数据集目录，默认 data")
    parser.add_argument("--result_dir", default="results", help="结果输出目录，默认 results")
    parser.add_argument(
        "--datasets",
        default="jm1,kc1,kc2,pc1",
        help="要运行的数据集名称，逗号分隔；也可写 all。默认 jm1,kc1,kc2,pc1",
    )
    parser.add_argument(
        "--k_values",
        default="2,3,4,5,6,7,8",
        help="候选聚类数，逗号分隔。默认 2,3,4,5,6,7,8",
    )
    parser.add_argument("--seed", type=int, default=2026, help="随机种子")
    parser.add_argument("--skip_failed", action="store_true", help="某个数据集失败时继续运行其他数据集")
    parser.add_argument("--save_plots", action="store_true", help="保存缺陷发现曲线和簇风险柱状图。默认只保存 CSV，加快运行速度")
    return parser.parse_args(argv)


if __name__ == "__main__":
    run_experiment(parse_args(sys.argv[1:]))
