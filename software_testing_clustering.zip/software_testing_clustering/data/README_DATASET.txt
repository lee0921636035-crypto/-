本文件夹用于存放真实数据集。
运行：python run_mrctp_jm1.py --download --data_dir data --result_dir results
程序会自动下载 JM1 数据集到：data/jm1.arff
数据源：https://raw.githubusercontent.com/ApoorvaKrisna/NASA-promise-dataset-repository/main/jm1.arff
